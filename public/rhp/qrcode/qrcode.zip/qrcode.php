	
	<?php
	require_once("funcoes.php");
			$aux = 'qr_img0.50j/php/qr_img.php?';
			$aux .= 'd=4711&';
			$aux .= 'e=H&';
			$aux .= 's=10&';
			$aux .= 't=J';

		?>


<!doctype html>
<html lang="pt">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Unimed Recife III</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/album.css" rel="stylesheet">
	
  </head>

  <body>

    <header>
      <div class="collapse bg-dark" id="navbarHeader">
        <div class="container">
          <div class="row">
            <div class="col-sm-8 col-md-7 py-4">
              <h4 class="text-white">Sobre</h4>
              <p class="text-muted">Prévia descrição sobre a página dos dilemas</p>
            </div>
            <div class="col-sm-4 offset-md-1 py-4">
              <h4 class="text-white">Menu</h4>
              <ul class="list-unstyled">
                <li><a href="http://192.168.22.10/escala_medica.html" class="text-white">Escalas Médicas</a></li>
                <li><a href="#" class="text-white">Escalas Enfermagem</a></li>
                <li><a href="#" class="text-white">Protocolos</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="navbar navbar-dark box-shadow" style="background-color:#3CB371;">
        <div class="container d-flex justify-content-between">
          <a href="#" class="navbar-brand d-flex align-items-center">
            <img src="img/unimedrecife.png" style="width:5em;">
			<strong>&nbsp;QRCode</strong>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
      </div>
    </header>

    <main role="main">

      <section class="text-center" style="padding:2em;" >
        <div class="container ">
          <p class="lead" >
            Impressão do QRCode para ultilização no glicosímetro.
          </p>
        </div>
      </section>

      <div class="album py-5 bg-light bg-dilema-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card mb-4 box-shadow">
                <div class="card-body">
                  <p class="card-text">Digite o seu <b> USUÁRIO </b> do MVPEP/MVSOUL, depois clique em <b>Gerar QRCode</b></p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
					<form action="qrcode_impressao.php" method="POST">
					  <input id="texto" name="usuario" type="text" style="text-transform: uppercase;" class="form-control" >
					  <button class="form-control btn btn-sm btn-outline-secondary">Gerar QRCode</button>
					  
					</form>  
                    </div>
                    <small class="text-muted">12/09/2016</small>
                  </div>
                </div>
              </div>
            </div>
		</div>
    </main>
	
	<?php
	$usuario = $_POST['usuario'];
	//var_dump($objeto);
			conexao();
			$sql = "SELECT cd_prestador from prestadores where cd_usuario = '$usuario'";
			$rs_view  = seleciona($sql);
			while($res_view = mysql_fetch_assoc($rs_view)){
				echo $cd_prestador = $res_view['cd_prestador'];
			}
				?>

    <footer class="text-muted">
	
      <div class="container">

        <p class="float-right">
          <a href="#">Voltar ao topo</a>
        </p>
        <p>Unimed Recife &copy; Todos os direitos reservados</p>
        <p class="float-right" data-toggle="collapse" data-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation"><a href="#" >Menu</a></p>
      </div>
	  
    </footer>

    <script src="js/jquery-3.2.1.slim.min.js" ></script>
    
    <script src="js/bootstrap.min.js"></script>

  </body>
</html>




<script type="text/javascript">

		</script>